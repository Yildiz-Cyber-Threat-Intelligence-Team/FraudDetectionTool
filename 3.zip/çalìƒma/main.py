import argparse
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import logging
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from kafka import KafkaProducer, KafkaConsumer
import json
import time
import random

logging.basicConfig(
    filename='fraud_detection.log',
    filemode='a',
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
def parse_arguments():
    parser = argparse.ArgumentParser(description='Fraud detection ve veri analizleri için gelişmiş bir CLI.')
    parser.add_argument('--file', type=str, required=True, help='Yüklenecek CSV dosyasının yolu')
    parser.add_argument('--operation', type=str, choices=[
        'head', 'describe', 'shape', 'fraud_rate', 'correlation', 'outliers', 
        'compare', 'plot_fraud', 'fraud_categories', 'fraud_trend', 'train_model', 'stream_kafka'], 
        required=True, help='Yapılacak işlem')
    return parser.parse_args()

def load_data(file_path):
    try:
        data = pd.read_csv(file_path)
        return data
    except FileNotFoundError:
        logging.error(f"Dosya bulunamadı: {file_path}")
        return None
    except pd.errors.EmptyDataError:
        logging.error(f"Boş veri dosyası: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Bir hata oluştu: {e}")
        return None

def calculate_fraud_rate(data):
    if 'is_fraud' not in data.columns:
        logging.error("Hata: 'is_fraud' sütunu bulunamadı.")
        return
    fraud_count = data[data['is_fraud'] == 1].shape[0]
    total_count = data.shape[0]
    fraud_rate = (fraud_count / total_count) * 100
    logging.info(f"Sahte işlemlerin oranı: %{fraud_rate:.2f}")

def calculate_correlation(data):
    logging.info("Veri setindeki korelasyonlar:\n" + str(data.corr()))

def detect_outliers(data):
    numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns
    for column in numeric_columns:
        q1 = data[column].quantile(0.25)
        q3 = data[column].quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        outliers = data[(data[column] < lower_bound) | (data[column] > upper_bound)]
        logging.info(f"Uç noktalar (outliers) - {column}:\n" + str(outliers))

def compare_fraud_nonfraud(data):
    if 'is_fraud' not in data.columns:
        logging.error("Hata: 'is_fraud' sütunu bulunamadı.")
        return
    fraud_data = data[data['is_fraud'] == 1]
    non_fraud_data = data[data['is_fraud'] == 0]
    logging.info(f"Gerçek işlemlerin ortalama tutarı: ${non_fraud_data['transaction_amount'].mean()}")
    logging.info(f"Sahte işlemlerin ortalama tutarı: ${fraud_data['transaction_amount'].mean()}")

def plot_fraud_distribution(data):
    if 'is_fraud' not in data.columns:
        logging.error("Hata: 'is_fraud' sütunu bulunamadı.")
        return
    sns.countplot(x='is_fraud', data=data)
    plt.title("Sahte ve Gerçek İşlemler Dağılımı")
    plt.savefig("fraud_distribution.png")
    plt.show()

def fraud_categories(data):
    if 'is_fraud' not in data.columns or 'merchant_category' not in data.columns:
        logging.error("Hata: Gerekli sütunlar bulunamadı.")
        return
    fraud_data = data[data['is_fraud'] == 1]
    logging.info("En çok sahte işlemler yapılan satıcı kategorileri:\n" + str(fraud_data['merchant_category'].value_counts()))

def fraud_trend(data):
    if 'is_fraud' not in data.columns or 'transaction_date' not in data.columns:
        logging.error("Hata: Gerekli sütunlar bulunamadı.")
        return
    data['transaction_date'] = pd.to_datetime(data['transaction_date'])
    fraud_trend_data = data.groupby(data['transaction_date'].dt.to_period('M')).is_fraud.sum()
    fraud_trend_data.plot(kind='line', title='Aylık Sahtekarlık Trendleri')
    plt.savefig("fraud_trend.png")
    plt.show()

def train_fraud_detection_model(data):
    if 'is_fraud' not in data.columns:
        logging.error("Hata: 'is_fraud' sütunu bulunamadı.")
        return
    X = data[['transaction_amount']]
    y = data['is_fraud']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    predictions = model.predict(X_test)
    
    logging.info("Sınıflandırma Raporu:\n" + str(classification_report(y_test, predictions)))
    logging.info("Karışıklık Matrisi:\n" + str(confusion_matrix(y_test, predictions)))

def kafka_producer(transaction):
    producer = KafkaProducer(bootstrap_servers='localhost:9092',
                         value_serializer=lambda v: json.dumps(v).encode('utf-8'))
    producer.send('credit_card_transactions', transaction)

def kafka_consumer(model):
    consumer = KafkaConsumer('credit_card_transactions',
                         bootstrap_servers='localhost:9092',
                         value_deserializer=lambda m: json.loads(m.decode('utf-8')))
    for message in consumer:
        transaction = message.value
        logging.info(f"Alınan İşlem: {transaction}")
        prediction = model.predict([[transaction['transaction_amount']]])
        if prediction == 1:
            logging.info(f"❗ Dolandırıcılık Tespit Edildi! İşlem ID: {transaction['transaction_id']}")
        else:
            logging.info(f"✔ Güvenli İşlem. İşlem ID: {transaction['transaction_id']}")

def stream_kafka():
    while True:
        transaction = {
            "transaction_id": random.randint(10000, 99999),
            "transaction_amount": round(random.uniform(1.0, 1000.0), 2),
            "timestamp": time.time(),
            "is_fraud": random.choice([0, 1])
        }
        kafka_producer(transaction)
        time.sleep(2)

def process_data(data, operation):
    if operation == 'head':
        logging.info("İlk 5 satır:\n" + str(data.head()))
    elif operation == 'describe':
        logging.info("Veri setinin istatistiksel özeti:\n" + str(data.describe()))
    elif operation == 'shape':
        logging.info(f"Veri seti {data.shape[0]} satır ve {data.shape[1]} sütundan oluşuyor.")
    elif operation == 'fraud_rate':
        calculate_fraud_rate(data)
    elif operation == 'correlation':
        calculate_correlation(data)
    elif operation == 'outliers':
        detect_outliers(data)
    elif operation == 'compare':
        compare_fraud_nonfraud(data)
    elif operation == 'plot_fraud':
        plot_fraud_distribution(data)
    elif operation == 'fraud_categories':
        fraud_categories(data)
    elif operation == 'fraud_trend':
        fraud_trend(data)
    elif operation == 'train_model':
        train_fraud_detection_model(data)
    elif operation == 'stream_kafka':
        stream_kafka()

if __name__ == "__main__":
    args = parse_arguments()
    data = load_data(args.file)
    
    if data is not None:
        process_data(data, args.operation)
